import React, { useState } from 'react';
import TaskForm from './components/TaskForm';
import TaskList from './components/TaskList';
import './App.css';

const App = () => {
  const [tasks, setTasks] = useState([]);

  const addTask = (newTask) => {
    setTasks([...tasks, newTask]);
  };

  const toggleTaskDone = (taskToUpdate) => {
    setTasks(tasks.map(task =>
      task.taskName === taskToUpdate.taskName
        ? { ...task, isDone: !task.isDone, timestamp: new Date() }
        : task
    ));
  };

  const editTask = (updatedTask) => {
    setTasks(tasks.map(task =>
      task.taskName === updatedTask.taskName ? updatedTask : task
    ));
  };

  return (
    <div className="App">
      <h1>TO DO List</h1>
      <TaskForm addTask={addTask} />
      <TaskList tasks={tasks} toggleTaskDone={toggleTaskDone} editTask={editTask} />
    </div>
  );
};

export default App;
