import React, { useState } from 'react';
import TaskItem from './TaskItem';

const TaskList = ({ tasks, toggleTaskDone, editTask }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTasks = tasks.filter(task =>
    task.taskName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    task.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div>
      <input
        type="text"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        placeholder="Search Tasks"
      />
      {filteredTasks.map(task => (
        <TaskItem
          key={task.taskName}
          task={task}
          toggleTaskDone={toggleTaskDone}
          editTask={editTask}
        />
      ))}
    </div>
  );
};

export default TaskList;
