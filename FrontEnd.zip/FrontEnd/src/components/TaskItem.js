import React, { useState } from 'react';

const TaskItem = ({ task, toggleTaskDone, editTask }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [taskName, setTaskName] = useState(task.taskName);
  const [description, setDescription] = useState(task.description);

  const handleSave = () => {
    editTask({ ...task, taskName, description });
    setIsEditing(false);
  };

  return (
    <div>
      <div onClick={() => setIsExpanded(!isExpanded)}>
        <h3 style={{ textDecoration: task.isDone ? 'line-through' : 'none' }}>
          {task.taskName}
        </h3>
      </div>
      {isExpanded && (
        <div>
          {isEditing ? (
            <>
              <input
                type="text"
                value={taskName}
                onChange={(e) => setTaskName(e.target.value)}
              />
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
              <button onClick={handleSave}>Save</button>
            </>
          ) : (
            <>
              <p>{task.description}</p>
              <p>Last updated: {new Date(task.timestamp).toLocaleString()}</p>
              <button onClick={() => setIsEditing(true)}>Edit</button>
            </>
          )}
          <button onClick={() => toggleTaskDone(task)}>
            {task.isDone ? 'Mark as Undone' : 'Mark as Done'}
          </button>
        </div>
      )}
    </div>
  );
};

export default TaskItem;
